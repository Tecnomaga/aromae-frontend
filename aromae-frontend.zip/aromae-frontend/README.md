# Aromaê — Frontend

Vitrine digital para revendedoras de perfumes: cadastro de produtos, controle de estoque, pedidos, clientes e um catálogo público para compartilhar no WhatsApp/Instagram.

Este pacote contém **só o frontend** (React + Vite + Tailwind, como PWA). O backend (Node/Express/MongoDB) ainda não existe — por isso, ao testar agora, as telas de lista aparecem vazias e os formulários mostrarão uma mensagem de erro de conexão ao salvar. Isso é esperado: toda a interface já está pronta e vai funcionar assim que o backend for criado.

## O que já está pronto

- Autenticação: login, cadastro e onboarding (carrossel de boas-vindas + criação da loja)
- Dashboard com cards de resumo e gráfico dos últimos 7 dias
- Produtos: lista com busca/filtro, formulário com upload de até 3 fotos, baixa de estoque e histórico
- Pedidos: lista com filtros, formulário com busca de cliente e itens dinâmicos
- Clientes: lista e formulário com máscara de telefone
- Perfil: editar loja, pausar/reabrir loja, compartilhar link
- Configurações: FAQ, suporte via WhatsApp, termos
- Catálogo público (`/loja/seu-slug`): vitrine para suas clientes, com botão "Pedir via WhatsApp"
- Identidade visual: fundo creme, rosa queimado + dourado, Playfair Display + Nunito

## Como rodar no seu computador

Você vai precisar do [Node.js](https://nodejs.org) instalado (versão 18 ou mais recente).

```bash
# 1. Entre na pasta do projeto
cd aromae-frontend

# 2. Instale as dependências
npm install

# 3. Rode o projeto
npm run dev
```

Depois é só abrir o endereço que aparecer no terminal (normalmente `http://localhost:3000`).

## Como rodar pelo celular (StackBlitz)

1. Acesse [stackblitz.com](https://stackblitz.com) e crie um projeto vazio "Node.js" ou "Vite".
2. Arraste a pasta `aromae-frontend` inteira para dentro do StackBlitz (ou envie o `.zip` e peça para extrair).
3. O StackBlitz instala as dependências e mostra o preview ao vivo automaticamente.

## Conectar ao backend

Quando o backend estiver no ar (local ou no Render), copie `.env.example` para `.env` e ajuste a URL:

```
VITE_API_URL=https://sua-api.onrender.com/api
```

## Deploy (Vercel)

1. Suba esta pasta para um repositório no GitHub.
2. Na [Vercel](https://vercel.com), importe o repositório — ela detecta o Vite automaticamente.
3. Em "Environment Variables", adicione `VITE_API_URL` apontando para sua API.
4. Clique em Deploy.

## Ícones do app (PWA)

Os arquivos `public/icon-192.png` e `public/icon-512.png` são placeholders com as cores da marca. Quando tiver uma logo definitiva, é só substituir esses dois arquivos (mesmo nome e tamanho) e o app instalável vai usá-la automaticamente.

## Próximo passo

Quando estiver satisfeita com o frontend, o próximo passo é construir o backend (Node + Express + MongoDB) com autenticação JWT, upload de imagens (Cloudinary) e as rotas de produtos, pedidos, clientes e catálogo público.
